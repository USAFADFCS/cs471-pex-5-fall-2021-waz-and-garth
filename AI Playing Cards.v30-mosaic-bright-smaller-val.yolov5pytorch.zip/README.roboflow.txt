
AI Playing Cards - v30 Mosaic Bright Smaller Val
==============================

This dataset was exported via roboflow.ai on December 3, 2021 at 4:24 AM GMT

It includes 616 images.
Playing-Cards are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -28 and +28 percent


